package com.sts;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProductCommunityBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProductCommunityBackendApplication.class, args);
	}

}
